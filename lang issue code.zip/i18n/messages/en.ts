const en = {
  common: {
    navigation: {
      home: "Home",
      about: "About Us",
      services: "Services",
      blog: "Blog",
      contact: "Contacts",
    },
    header: {
      menu: "Menu",
      close: "Close",
      contactUs: "Contact Us",
      language: "Language",
    },
  },
};

export default en;
