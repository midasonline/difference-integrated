const ar = {
  common: {
    navigation: {
      home: "الرئيسية",
      about: "من نحن",
      services: "الخدمات",
      blog: "المدونة",
      contact: "اتصل بنا",
    },
    header: {
      menu: "القائمة",
      close: "إغلاق",
      contactUs: "تواصل معنا",
      language: "اللغة",
    },
  },
};

export default ar;
