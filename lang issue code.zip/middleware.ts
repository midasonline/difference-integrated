import { NextResponse, type NextRequest } from "next/server";

import {
  defaultLocale,
  isLocale,
  localeCookieName,
  type Locale,
} from "./i18n/config";
import { stripLocaleFromPathname } from "./i18n/routing";

function getPathLocale(pathname: string): Locale | null {
  const firstSegment = pathname.split("/").filter(Boolean)[0];
  return isLocale(firstSegment) ? firstSegment : null;
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const pathLocale = getPathLocale(pathname);

  // Keep English as the canonical, unprefixed route: /about instead of /en/about.
  if (pathLocale === defaultLocale) {
    const url = request.nextUrl.clone();
    url.pathname = stripLocaleFromPathname(pathname);

    const response = NextResponse.redirect(url);
    response.cookies.set(localeCookieName, defaultLocale, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
      sameSite: "lax",
    });

    return response;
  }

  // If the URL already contains a supported locale, use it and remember it.
  if (pathLocale) {
    const requestHeaders = new Headers(request.headers);
    requestHeaders.set("x-di-locale", pathLocale);

    const response = NextResponse.next({
      request: {
        headers: requestHeaders,
      },
    });

    response.cookies.set(localeCookieName, pathLocale, {
      path: "/",
      maxAge: 60 * 60 * 24 * 365,
      sameSite: "lax",
    });

    return response;
  }

  const savedLocale = request.cookies.get(localeCookieName)?.value;

  // Preserve the selected non-default language even when an existing component
  // still points to an unprefixed internal URL.
  if (isLocale(savedLocale) && savedLocale !== defaultLocale) {
    const url = request.nextUrl.clone();
    url.pathname = pathname === "/" ? `/${savedLocale}` : `/${savedLocale}${pathname}`;
    return NextResponse.redirect(url);
  }

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-di-locale", defaultLocale);

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

export const config = {
  matcher: [
    "/((?!api|_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|assets|.*\\..*).*)",
  ],
};
